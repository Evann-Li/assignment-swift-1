let testArray = [2, 4, 5, 1, 3, 5, 4]

func firstDuplicatedElement(in array: [Int]) -> Int? {
    // key = integer value, value = index in array
    var seen = [Int: Int]()
    // track the 1st dupl indx value
    var dupIdx = array.count
    //loop through numbers so u can find index
    for (index, value) in array.enumerated() {
        // see if it matches
        if seen.keys.contains(value) {
          // ??
          let idx = seen[value]!
          // To make sure the pair is the first one
          if dupIdx > idx {
              dupIdx = idx
          }
        } else {
            seen[value] = index
        }
    }
    
    if (dupIdx < array.count) {
        return array[dupIdx]
    }
    return nil
}

if let duplicate = firstDuplicatedElement(in: testArray) {
  print(duplicate) // prints 4
}