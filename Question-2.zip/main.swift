import Foundation
//function to flip the word around
func isPalindrome(_ word: String) -> Bool {
  let trimmed = word.trimmingCharacters(in: .whitespacesAndNewlines)
  let reversed = String(trimmed)
  let isPal = trimmed == reversed
  print("check \(word) flipped: \(reversed)")
  return isPal;
}

// test to see if when flipped, the word is the same
print("bob= \(isPalindrome("bob"))")
print("radar= \(isPalindrome("radar"))")
print("noway= \(isPalindrome("noway"))")
print("coppoc= \(isPalindrome("coppoc"))")
// boundary conditions - does it still work? should it still work?
print( isPalindrome("bob ")) 
print( isPalindrome(" ")) 
print( isPalindrome("")) 
print( isPalindrome("asdf"))
//print( (isPalindrome(nil))   